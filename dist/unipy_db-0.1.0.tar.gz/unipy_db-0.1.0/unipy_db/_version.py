# -*- coding: utf-8 -*-
"""
Created on Sun Jan  8 03:46:03 2017

@author: Young Ju Kim
"""


__all__ = ['__version__']

__version__ = '0.0.6'

